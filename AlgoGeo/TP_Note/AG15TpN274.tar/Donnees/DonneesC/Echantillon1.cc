int n=10;
point segments[2*n];

segments[0].abscisse=202;
segments[0].ordonnee=203;
segments[1].abscisse=351;
segments[1].ordonnee=223;
segments[2].abscisse=52;
segments[2].ordonnee=616;
segments[3].abscisse=235;
segments[3].ordonnee=647;
segments[4].abscisse=250;
segments[4].ordonnee=100;
segments[5].abscisse=381;
segments[5].ordonnee=246;
segments[6].abscisse=332;
segments[6].ordonnee=124;
segments[7].abscisse=453;
segments[7].ordonnee=77;
segments[8].abscisse=318;
segments[8].ordonnee=613;
segments[9].abscisse=485;
segments[9].ordonnee=649;
segments[10].abscisse=206;
segments[10].ordonnee=146;
segments[11].abscisse=258;
segments[11].ordonnee=159;
segments[12].abscisse=24;
segments[12].ordonnee=287;
segments[13].abscisse=221;
segments[13].ordonnee=331;
segments[14].abscisse=26;
segments[14].ordonnee=267;
segments[15].abscisse=115;
segments[15].ordonnee=288;
segments[16].abscisse=75;
segments[16].ordonnee=114;
segments[17].abscisse=174;
segments[17].ordonnee=130;
segments[18].abscisse=246;
segments[18].ordonnee=242;
segments[19].abscisse=510;
segments[19].ordonnee=225;



