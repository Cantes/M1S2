package util;

public class SingularMatrixException extends Exception {

	private static final long serialVersionUID = 1L;

}
