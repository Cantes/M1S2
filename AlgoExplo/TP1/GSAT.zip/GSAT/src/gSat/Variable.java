package gSat;


public class Variable {

	private int id;
	private boolean valeur;
		
	public Variable(int val){
		if(val < 0){
			this.id = Math.abs(val);
			this.valeur = false;
		}else{
			this.id = val;
			this.valeur = true;
		}
	}
		
	public void changeValeur(){
		this.valeur = !this.valeur;
	}
	
	public boolean getValeur(){
		return this.valeur;
	}
	
	public void setValeur(boolean val){
		this.valeur = val;
	}
}
