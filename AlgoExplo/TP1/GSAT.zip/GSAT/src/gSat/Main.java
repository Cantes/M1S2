package gSat;

public class Main {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String s = "/auto_home/bcommandre/Bureau/M1_S2/AlgoExplo/TP1/uf20-91/uf20-01.cnf";
		CSP myCSP = new CSP();
		myCSP.parser(s);
		myCSP.affiche();

	}

}
