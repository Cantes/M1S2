package gSat;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class CSP {

	private ArrayList<Clause> listeClause;

	public CSP() {
		this.listeClause = new ArrayList<Clause>();
	}

	public CSP(int nb) {
		this.listeClause = new ArrayList<Clause>(nb);
	}

	public void ajouteClause(Clause c) {
		this.listeClause.add(c);
	}

	public void affiche() {
		for (int i = 0; i < this.listeClause.size(); i++) {
			System.out.println(this.listeClause.get(i).toString());
		}
	}

	public ArrayList<Clause> getClause() {
		return this.listeClause;
	}

	public void parser(String nomFichier) {

		int nbClause = 0;
		int nbVariable;
		String[] tab;

		try {
			BufferedReader buff = new BufferedReader(new FileReader(nomFichier));
			try {
				String line;
				boolean test = true;
				while ((line = buff.readLine()) != null && test) {
					tab = line.split(" ");
					if (!tab[0].equals("c")) {
						test = false;
						break;
					}
				}
				
				tab = line.split(" ");
				nbClause = Integer.parseInt(tab[4]);
				nbVariable = Integer.parseInt(tab[2]);
				

				for (int i = 0; i < nbClause; i++) {
					line = buff.readLine();
					tab = line.split(" ");
					Clause c = new Clause();
					for (int j = 0; j < 3; j++) {
						if(i==0){
							Variable v = new Variable(Integer.parseInt(tab[j+1]));
							c.ajouteVariable(v);
						}else{
							Variable v = new Variable(Integer.parseInt(tab[j]));
							c.ajouteVariable(v);
						}

					}
					this.ajouteClause(c);
				}

			} finally {
				buff.close();
			}
		} catch (IOException ioe) {
			System.out.println("Erreur --" + ioe.toString());
		}

	}

}
