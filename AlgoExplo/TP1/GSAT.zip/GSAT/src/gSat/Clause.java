package gSat;

import java.util.ArrayList;

public class Clause {
	
	private ArrayList<Variable> clause;
	
	public Clause(){
		this.clause = new ArrayList<Variable>(3);
	}
	
	public void ajouteVariable(Variable v){
		if(this.clause.size() < 3){
			this.clause.add(v);
		}
	}
	
	public boolean estSatisfiable(){
		for(int i=0; i<clause.size(); i++){
			if (clause.get(i).getValeur()){
				return true;
			}
		}
		return false;
	}
	
	public String toString(){
		String s = "";
		for(int i =0; i<3; i++){
			if(i !=2){
				s = s + this.clause.get(i) + ",";
			}else{
				s = s + this.clause.get(i) + ";";
			}
			
		}
		return s;
	}

}
